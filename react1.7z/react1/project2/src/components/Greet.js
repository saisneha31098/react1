import React from 'react'
/*function Greet(){
    return <h1>hello sneha</h1>
} */
const Greet = () => <h1>hello sneha</h1>
export default Greet