import React from 'react'
 const Greet = ({name,info}) => {
    
     return (
         <div>
             <h1>
                 Hello {name} s.n.e {info}
             </h1>
         </div>
     )
 }
 export default Greet